module.exports = {
  bootstrap: "src/bootstrap.tsx",
};
