import React, { FunctionComponent } from "react";
import { BrowserRouter as Router } from "react-router-dom";
import "normalize.css";

export const Bootstrap: FunctionComponent = ({ children }) => (
  <React.StrictMode>
    <Router>{children}</Router>
  </React.StrictMode>
);
