import React, { FunctionComponent } from "react";

export const Bootstrap: FunctionComponent = ({ children }) => (
  <React.StrictMode>{children}</React.StrictMode>
);
