import React from "react";
import "./App.css";

function App() {
  return (
    <div
      style={{
        display: "flex",
        minHeight: "100vh",
        flexDirection: "column",
      }}
    />
  );
}

export default App;
